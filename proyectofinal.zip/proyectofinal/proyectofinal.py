def asegurar_existencia_carpetas():
    # Proceso: Intenta crear las carpetas necesarias dentro de proyectofinal usando utf-8.
    try:
        archivo_prueba_1 = open("proyectofinal/ordenes_abiertas/temp_check.txt", "a", encoding="utf-8")
        archivo_prueba_1.close()
        
        archivo_prueba_2 = open("proyectofinal/ordenes_cerradas/temp_check.txt", "a", encoding="utf-8")
        archivo_prueba_2.close()
    except FileNotFoundError as error_archivo:
        pass
    except KeyError as error_clave:
        pass
    except ValueError as error_valor:
        pass
    except Exception as error_general:
        pass

def verificar_si_archivo_existe(ruta_del_archivo):
    # Proceso: Intenta abrir un archivo en modo lectura con utf-8 para comprobar su existencia.
    try:
        archivo_en_memoria = open(ruta_del_archivo, "r", encoding="utf-8")
        archivo_en_memoria.close()
        return True
    except FileNotFoundError as error_archivo:
        return False
    except KeyError as error_clave:
        return False
    except ValueError as error_valor:
        return False
    except Exception as error_general:
        return False

def listar_todos_los_archivos_de_ordenes(nombre_de_la_carpeta):
    # Proceso: Recorre un rango secuencial numérico para ubicar los archivos de órdenes de trabajo (OT) existentes.
    lista_de_nombres_de_ots = []
    numero_iteracion = 1
    while numero_iteracion <= 100:
        try:
            texto_numero = str(numero_iteracion)
            if numero_iteracion < 10:
                texto_numero = "00" + texto_numero
            elif numero_iteracion < 100:
                texto_numero = "0" + texto_numero
            nombre_archivo_ot = "OT" + texto_numero + ".txt"
            ruta_completa_archivo = "proyectofinal/" + nombre_de_la_carpeta + "/" + nombre_archivo_ot
            archivo_en_memoria = open(ruta_completa_archivo, "r", encoding="utf-8")
            archivo_en_memoria.close()
            lista_de_nombres_de_ots.append(nombre_archivo_ot)
        except FileNotFoundError as error_archivo:
            pass
        except KeyError as error_clave:
            pass
        except ValueError as error_valor:
            pass
        except Exception as error_general:
            pass
        numero_iteracion = numero_iteracion + 1
    return lista_de_nombres_de_ots

def cargar_datos_desde_archivo_csv(ruta_del_csv):
    # Proceso: Lee un archivo CSV con utf-8, extrae la cabecera y convierte cada fila en un diccionario de datos.
    lista_de_registros_cargados = []
    try:
        if not verificar_si_archivo_existe(ruta_del_csv):
            return lista_de_registros_cargados
        archivo_csv = open(ruta_del_csv, "r", encoding="utf-8")
        lineas_del_archivo = archivo_csv.readlines()
        archivo_csv.close()
        
        if len(lineas_del_archivo) <= 1:
            return lista_de_registros_cargados
        
        lista_cabeceras = lineas_del_archivo[0].strip().split(",")
        indice_fila = 1
        while indice_fila < len(lineas_del_archivo):
            texto_fila_actual = lineas_del_archivo[indice_fila].strip()
            if texto_fila_actual != "":
                valores_de_la_fila = texto_fila_actual.split(",")
                diccionario_fila_actual = {}
                indice_columna = 0
                while indice_columna < len(lista_cabeceras):
                    if indice_columna < len(valores_de_la_fila):
                        diccionario_fila_actual[lista_cabeceras[indice_columna]] = valores_de_la_fila[indice_columna].strip()
                    else:
                        diccionario_fila_actual[lista_cabeceras[indice_columna]] = ""
                    indice_columna = indice_columna + 1
                lista_de_registros_cargados.append(diccionario_fila_actual)
            indice_fila = indice_fila + 1
    except FileNotFoundError as error_archivo:
        pass
    except KeyError as error_clave:
        pass
    except ValueError as error_valor:
        pass
    except Exception as error_general:
        pass
    return lista_de_registros_cargados

def guardar_datos_equipos_en_csv(ruta_equipos, lista_equipos_actualizada):
    # Proceso: Sobrescribe el archivo de equipos con los estados actualizados usando utf-8.
    try:
        archivo_equipos = open(ruta_equipos, "w", encoding="utf-8")
        archivo_equipos.write("equipo_id,cliente,tipo,modelo,estado\n")
        for equipo_individual in lista_equipos_actualizada:
            linea_equipo_texto = equipo_individual["equipo_id"] + "," + equipo_individual["cliente"] + "," + equipo_individual["tipo"] + "," + equipo_individual["modelo"] + "," + equipo_individual["estado"] + "\n"
            archivo_equipos.write(linea_equipo_texto)
        archivo_equipos.close()
    except FileNotFoundError as error_archivo:
        pass
    except KeyError as error_clave:
        pass
    except ValueError as error_valor:
        pass
    except Exception as error_general:
        pass

def guardar_datos_repuestos_en_csv(ruta_repuestos, lista_repuestos_actualizada):
    # Proceso: Sobrescribe el inventario de repuestos actualizando existencias en stock usando utf-8.
    try:
        archivo_repuestos = open(ruta_repuestos, "w", encoding="utf-8")
        archivo_repuestos.write("codigo,descripcion,costo_compra,precio_venta,stock\n")
        for repuesto_individual in lista_repuestos_actualizada:
            linea_repuesto_texto = repuesto_individual["codigo"] + "," + repuesto_individual["descripcion"] + "," + str(repuesto_individual["costo_compra"]) + "," + str(repuesto_individual["precio_venta"]) + "," + str(repuesto_individual["stock"]) + "\n"
            archivo_repuestos.write(linea_repuesto_texto)
        archivo_repuestos.close()
    except FileNotFoundError as error_archivo:
        pass
    except KeyError as error_clave:
        pass
    except ValueError as error_valor:
        pass
    except Exception as error_general:
        pass

def leer_contenido_orden_txt(ruta_archivo_orden):
    # Proceso: Lee un archivo de orden de trabajo con utf-8 y separa la cabecera de las líneas de contenido.
    diccionario_informacion_orden = {
        "cabecera": {},
        "lineas": []
    }
    try:
        if not verificar_si_archivo_existe(ruta_archivo_orden):
            return diccionario_informacion_orden
        archivo_orden = open(ruta_archivo_orden, "r", encoding="utf-8")
        lineas_del_archivo_orden = archivo_orden.readlines()
        archivo_orden.close()
        
        for linea_individual in lineas_del_archivo_orden:
            linea_limpia_de_espacios = linea_individual.strip()
            if linea_limpia_de_espacios != "":
                partes_separadas_por_barra = linea_limpia_de_espacios.split("|")
                tipo_de_registro = partes_separadas_por_barra[0]
                if tipo_de_registro == "ORDEN":
                    diccionario_informacion_orden["cabecera"] = {
                        "ot": partes_separadas_por_barra[1],
                        "equipo_id": partes_separadas_por_barra[2],
                        "fecha": partes_separadas_por_barra[3],
                        "estado": partes_separadas_por_barra[4]
                    }
                else:
                    diccionario_informacion_orden["lineas"].append(partes_separadas_por_barra)
    except FileNotFoundError as error_archivo:
        pass
    except KeyError as error_clave:
        pass
    except ValueError as error_valor:
        pass
    except Exception as error_general:
        pass
    return diccionario_informacion_orden

def guardar_orden_en_txt(ruta_archivo_orden, diccionario_cabecera, lista_lineas_orden):
    # Proceso: Escribe de forma persistente la orden de trabajo en formato de texto plano usando utf-8.
    try:
        archivo_orden = open(ruta_archivo_orden, "w", encoding="utf-8")
        linea_cabecera_texto = "ORDEN|" + diccionario_cabecera["ot"] + "|" + diccionario_cabecera["equipo_id"] + "|" + diccionario_cabecera["fecha"] + "|" + diccionario_cabecera["estado"] + "\n"
        archivo_orden.write(linea_cabecera_texto)
        for linea_individual in lista_lineas_orden:
            texto_linea_unida = "|".join(linea_individual) + "\n"
            archivo_orden.write(texto_linea_unida)
        archivo_orden.close()
    except FileNotFoundError as error_archivo:
        pass
    except KeyError as error_clave:
        pass
    except ValueError as error_valor:
        pass
    except Exception as error_general:
        pass

def logica_abrir_nueva_orden(id_equipo_ingresado, codigo_ot_nuevo, fecha_orden_ingresada, lista_equipos):
    # Proceso: Valida reglas de negocio y crea la orden de manera segura en la carpeta. Retorna mensaje.
    try:
        equipo_encontrado_en_catalogo = None
        for equipo_item in lista_equipos:
            if equipo_item["equipo_id"] == id_equipo_ingresado:
                equipo_encontrado_en_catalogo = equipo_item
                break
                
        if equipo_encontrado_en_catalogo is None:
            return "Error: El equipo no existe en el catálogo."
            
        if equipo_encontrado_en_catalogo["estado"] != "DISPONIBLE":
            return "Error: El equipo ya se encuentra OCUPADO o no está disponible."
            
        archivos_existentes_ots = listar_todos_los_archivos_de_ordenes("ordenes_abiertas")
        for archivo_ot_nombre in archivos_existentes_ots:
            datos_orden_existente = leer_contenido_orden_txt("proyectofinal/ordenes_abiertas/" + archivo_ot_nombre)
            if datos_orden_existente["cabecera"].get("equipo_id") == id_equipo_ingresado and datos_orden_existente["cabecera"].get("estado") == "ABIERTA":
                return "Error: El equipo ya tiene una orden abierta."

        ruta_archivo_nueva_ot = "proyectofinal/ordenes_abiertas/" + codigo_ot_nuevo + ".txt"
        if verificar_si_archivo_existe(ruta_archivo_nueva_ot):
            return "Error: Ya existe una orden con ese código."
            
        diccionario_cabecera_nueva = {
            "ot": codigo_ot_nuevo,
            "equipo_id": id_equipo_ingresado,
            "fecha": fecha_orden_ingresada,
            "estado": "ABIERTA"
        }
        
        guardar_orden_en_txt(ruta_archivo_nueva_ot, diccionario_cabecera_nueva, [])
        
        equipo_encontrado_en_catalogo["estado"] = "OCUPADO"
        guardar_datos_equipos_en_csv("proyectofinal/equipos.csv", lista_equipos)
        
        return f"¡Orden {codigo_ot_nuevo} abierta exitosamente!"
    except KeyError as error_clave:
        return f"Error de referencia de clave: {error_clave}"
    except ValueError as error_valor:
        return f"Error de valor ingresado: {error_valor}"
    except Exception as error_general:
        return f"Se ha producido un error inesperado: {error_general}"

def logica_anadir_servicio(codigo_ot_objetivo, codigo_servicio_ingresado, lista_equipos, lista_servicios):
    # Proceso: Añade una línea de servicio controlando posibles errores. Retorna mensaje.
    try:
        ruta_archivo_ot_objetivo = "proyectofinal/ordenes_abiertas/" + codigo_ot_objetivo + ".txt"
        if not verificar_si_archivo_existe(ruta_archivo_ot_objetivo):
            return "Error: La orden abierta no existe en la carpeta."
            
        datos_orden_actual = leer_contenido_orden_txt(ruta_archivo_ot_objetivo)
        cabecera_orden_actual = datos_orden_actual["cabecera"]
        lista_lineas_actuales = datos_orden_actual["lineas"]
        
        tipo_de_equipo_asociado = "FIJO"
        for equipo_item in lista_equipos:
            if equipo_item["equipo_id"] == cabecera_orden_actual["equipo_id"]:
                tipo_de_equipo_asociado = equipo_item["tipo"]
                break
                
        servicio_encontrado = None
        for servicio_item in lista_servicios:
            if servicio_item["codigo"] == codigo_servicio_ingresado:
                servicio_encontrado = servicio_item
                break
                
        if servicio_encontrado is None:
            return "Error: Servicio no encontrado."
            
        if tipo_de_equipo_asociado == "FIJO":
            costo_mano_obra = servicio_encontrado["costo_fijo"]
        else:
            costo_mano_obra = servicio_encontrado["costo_movil"]
            
        nueva_linea_servicio = ["SERVICIO", codigo_servicio_ingresado, str(costo_mano_obra)]
        lista_lineas_actuales.append(nueva_linea_servicio)
        guardar_orden_en_txt(ruta_archivo_ot_objetivo, cabecera_orden_actual, lista_lineas_actuales)
        return "¡Servicio añadido correctamente a la orden!"
    except KeyError as error_clave:
        return f"Error de referencia de clave: {error_clave}"
    except ValueError as error_valor:
        return f"Error de valor ingresado: {error_valor}"
    except Exception as error_general:
        return f"Se ha producido un error inesperado: {error_general}"

def logica_anadir_repuesto(codigo_ot_objetivo, codigo_repuesto_ingresado, cantidad_repuestos_pedida, lista_repuestos):
    # Proceso: Valida stock y descuenta inventario de forma segura. Retorna mensaje.
    try:
        ruta_archivo_ot_objetivo = "proyectofinal/ordenes_abiertas/" + codigo_ot_objetivo + ".txt"
        if not verificar_si_archivo_existe(ruta_archivo_ot_objetivo):
            return "Error: La orden abierta no existe."
            
        datos_orden_actual = leer_contenido_orden_txt(ruta_archivo_ot_objetivo)
        cabecera_orden_actual = datos_orden_actual["cabecera"]
        lista_lineas_actuales = datos_orden_actual["lineas"]
        
        repuesto_encontrado = None
        for repuesto_item in lista_repuestos:
            if repuesto_item["codigo"] == codigo_repuesto_ingresado:
                repuesto_encontrado = repuesto_item
                break
                
        if repuesto_encontrado is None:
            return "Error: Repuesto no encontrado."
            
        stock_actual_disponible = int(repuesto_encontrado["stock"])
        if cantidad_repuestos_pedida <= 0:
            return "Error: La cantidad debe ser mayor a cero."
            
        if cantidad_repuestos_pedida > stock_actual_disponible:
            return f"Error: Stock insuficiente. Stock disponible: {stock_actual_disponible}"
            
        repuesto_encontrado["stock"] = str(stock_actual_disponible - cantidad_repuestos_pedida)
        guardar_datos_repuestos_en_csv("proyectofinal/repuestos.csv", lista_repuestos)
        
        nueva_linea_repuesto = ["REPUESTO", codigo_repuesto_ingresado, str(cantidad_repuestos_pedida), str(repuesto_encontrado["precio_venta"]), str(repuesto_encontrado["costo_compra"])]
        lista_lineas_actuales.append(nueva_linea_repuesto)
        guardar_orden_en_txt(ruta_archivo_ot_objetivo, cabecera_orden_actual, lista_lineas_actuales)
        return "¡Repuesto añadido y stock actualizado exitosamente!"
    except KeyError as error_clave:
        return f"Error de referencia de clave: {error_clave}"
    except ValueError as error_valor:
        return f"Error de valor ingresado: {error_valor}"
    except Exception as error_general:
        return f"Se ha producido un error inesperado: {error_general}"

def logica_registrar_prueba(codigo_ot_objetivo, tipo_de_prueba_ingresado, valor_porcentaje_error):
    # Proceso: Registra pruebas de calibración controlando conversiones. Retorna mensaje.
    try:
        ruta_archivo_ot_objetivo = "proyectofinal/ordenes_abiertas/" + codigo_ot_objetivo + ".txt"
        if not verificar_si_archivo_existe(ruta_archivo_ot_objetivo):
            return "Error: La orden abierta no existe."
            
        if tipo_de_prueba_ingresado not in ["INICIAL", "FINAL"]:
            return "Error: Tipo de prueba inválido."
            
        if valor_porcentaje_error < 0:
            return "Error: El error no puede ser negativo."
            
        datos_orden_actual = leer_contenido_orden_txt(ruta_archivo_ot_objetivo)
        cabecera_orden_actual = datos_orden_actual["cabecera"]
        lista_lineas_actuales = datos_orden_actual["lineas"]
        
        nueva_linea_prueba = ["PRUEBA", tipo_de_prueba_ingresado, str(valor_porcentaje_error)]
        lista_lineas_actuales.append(nueva_linea_prueba)
        guardar_orden_en_txt(ruta_archivo_ot_objetivo, cabecera_orden_actual, lista_lineas_actuales)
        return "¡Prueba registrada exitosamente!"
    except KeyError as error_clave:
        return f"Error de referencia de clave: {error_clave}"
    except ValueError as error_valor:
        return f"Error de valor ingresado: {error_valor}"
    except Exception as error_general:
        return f"Se ha producido un error inesperado: {error_general}"

def logica_simular_cierre(codigo_ot_objetivo):
    # Proceso: Evalúa si la orden cumple requisitos de cierre. Retorna diccionario.
    try:
        ruta_archivo_ot_objetivo = "proyectofinal/ordenes_abiertas/" + codigo_ot_objetivo + ".txt"
        if not verificar_si_archivo_existe(ruta_archivo_ot_objetivo):
            return {"valido": False, "mensaje": "Error: La orden no existe."}
            
        datos_orden_actual = leer_contenido_orden_txt(ruta_archivo_ot_objetivo)
        lista_lineas_actuales = datos_orden_actual["lineas"]
        
        bandera_tiene_servicio = False
        bandera_tiene_inicial = False
        ultimo_valor_final_registrado = None
        
        for linea_individual in lista_lineas_actuales:
            if linea_individual[0] == "SERVICIO":
                bandera_tiene_servicio = True
            elif linea_individual[0] == "PRUEBA":
                if linea_individual[1] == "INICIAL":
                    bandera_tiene_inicial = True
                elif linea_individual[1] == "FINAL":
                    ultimo_valor_final_registrado = float(linea_individual[2])
                    
        resultado_simulacion = {
            "tiene_servicio": bandera_tiene_servicio,
            "tiene_inicial": bandera_tiene_inicial,
            "ultima_final": ultimo_valor_final_registrado,
            "estado": ""
        }
        
        if not bandera_tiene_servicio or not bandera_tiene_inicial or ultimo_valor_final_registrado is None:
            resultado_simulacion["estado"] = "NO APTO PARA CIERRE (Faltan requisitos obligatorios)."
        elif ultimo_valor_final_registrado <= 5.0:
            resultado_simulacion["estado"] = "APTO PARA CIERRE (Cumple umbral de error <= 5%)."
        else:
            resultado_simulacion["estado"] = "CALIBRACIÓN FALLIDA (Error final > 5%. La orden se mantendrá abierta)."
            
        return resultado_simulacion
    except KeyError as error_clave:
        return {"valido": False, "mensaje": f"Error de referencia de clave: {error_clave}"}
    except ValueError as error_valor:
        return {"valido": False, "mensaje": f"Error de valor ingresado: {error_valor}"}
    except Exception as error_general:
        return {"valido": False, "mensaje": f"Se ha producido un error inesperado: {error_general}"}

def logica_cerrar_y_facturar_orden(codigo_ot_objetivo, lista_equipos):
    # Proceso: Valida umbrales, calcula factura, traslada a cerradas y libera equipo. Retorna diccionario.
    try:
        ruta_archivo_ot_objetivo = "proyectofinal/ordenes_abiertas/" + codigo_ot_objetivo + ".txt"
        if not verificar_si_archivo_existe(ruta_archivo_ot_objetivo):
            return {"exito": False, "mensaje": "Error: La orden abierta no existe."}
            
        datos_orden_actual = leer_contenido_orden_txt(ruta_archivo_ot_objetivo)
        cabecera_orden_actual = datos_orden_actual["cabecera"]
        lista_lineas_actuales = datos_orden_actual["lineas"]
        
        bandera_tiene_servicio = False
        bandera_tiene_inicial = False
        ultimo_valor_final_registrado = None
        
        for linea_individual in lista_lineas_actuales:
            if linea_individual[0] == "SERVICIO":
                bandera_tiene_servicio = True
            elif linea_individual[0] == "PRUEBA":
                if linea_individual[1] == "INICIAL":
                    bandera_tiene_inicial = True
                elif linea_individual[1] == "FINAL":
                    ultimo_valor_final_registrado = float(linea_individual[2])
                    
        if not bandera_tiene_servicio or not bandera_tiene_inicial or ultimo_valor_final_registrado is None:
            return {"exito": False, "mensaje": "Error: La orden no cumple con los requisitos mínimos (Servicio, Prueba Inicial y Prueba Final obligatorios)."}
            
        if ultimo_valor_final_registrado > 5.0:
            return {"exito": False, "mensaje": f"¡CALIBRACIÓN FALLIDA! El error final es de {ultimo_valor_final_registrado}% (mayor a 5%). La orden se mantiene ABIERTA."}
            
        acumulado_mano_obra = 0.0
        acumulado_repuestos = 0.0
        
        for linea_individual in lista_lineas_actuales:
            if linea_individual[0] == "SERVICIO":
                acumulado_mano_obra = acumulado_mano_obra + float(linea_individual[2])
            elif linea_individual[0] == "REPUESTO":
                cantidad_repuesto = float(linea_individual[2])
                precio_venta_unitario = float(linea_individual[3])
                acumulado_repuestos = acumulado_repuestos + (cantidad_repuesto * precio_venta_unitario)
                
        subtotal_general_orden = acumulado_mano_obra + acumulado_repuestos
        iva_academico = subtotal_general_orden * 0.19
        total_a_pagar_factura = subtotal_general_orden + iva_academico
        
        cabecera_orden_actual["estado"] = "CERRADA"
        
        # Guardar en carpeta de cerradas y limpiar de abiertas
        ruta_archivo_orden_cerrada = "proyectofinal/ordenes_cerradas/" + codigo_ot_objetivo + ".txt"
        guardar_orden_en_txt(ruta_archivo_orden_cerrada, cabecera_orden_actual, lista_lineas_actuales)
        guardar_orden_en_txt(ruta_archivo_ot_objetivo, cabecera_orden_actual, [])
        
        for equipo_item in lista_equipos:
            if equipo_item["equipo_id"] == cabecera_orden_actual["equipo_id"]:
                equipo_item["estado"] = "DISPONIBLE"
                break
        guardar_datos_equipos_en_csv("proyectofinal/equipos.csv", lista_equipos)
        
        return {
            "exito": True,
            "ot": codigo_ot_objetivo,
            "equipo": cabecera_orden_actual["equipo_id"],
            "mano_obra": acumulado_mano_obra,
            "repuestos": acumulado_repuestos,
            "subtotal": subtotal_general_orden,
            "iva": iva_academico,
            "total": total_a_pagar_factura
        }
    except KeyError as error_clave:
        return {"exito": False, "mensaje": f"Error de referencia de clave: {error_clave}"}
    except ValueError as error_valor:
        return {"exito": False, "mensaje": f"Error de valor ingresado: {error_valor}"}
    except Exception as error_general:
        return {"exito": False, "mensaje": f"Se ha producido un error inesperado: {error_general}"}

def calcular_reportes_tecnicos():
    # Proceso: Procesa el histórico de órdenes cerradas controlando excepciones. Retorna diccionario.
    try:
        archivos_cerrados_encontrados = listar_todos_los_archivos_de_ordenes("ordenes_cerradas")
        diccionario_total_facturado_por_servicio = {}
        diccionario_conteo_veces_servicio = {}
        acumulado_margen_bruto_repuestos = 0.0
        acumulado_suma_errores_finales = 0.0
        contador_pruebas_finales_totales = 0
        
        for archivo_cerrado_nombre in archivos_cerrados_encontrados:
            datos_orden_cerrada = leer_contenido_orden_txt("proyectofinal/ordenes_cerradas/" + archivo_cerrado_nombre)
            for linea_individual in datos_orden_cerrada["lineas"]:
                if linea_individual[0] == "SERVICIO":
                    codigo_servicio = linea_individual[1]
                    costo_servicio_aplicado = float(linea_individual[2])
                    if codigo_servicio not in diccionario_total_facturado_por_servicio:
                        diccionario_total_facturado_por_servicio[codigo_servicio] = 0.0
                        diccionario_conteo_veces_servicio[codigo_servicio] = 0
                    diccionario_total_facturado_por_servicio[codigo_servicio] = diccionario_total_facturado_por_servicio[codigo_servicio] + costo_servicio_aplicado
                    diccionario_conteo_veces_servicio[codigo_servicio] = diccionario_conteo_veces_servicio[codigo_servicio] + 1
                elif linea_individual[0] == "REPUESTO":
                    cantidad_repuesto = float(linea_individual[2])
                    precio_venta_congelado = float(linea_individual[3])
                    costo_compra_congelado = float(linea_individual[4])
                    acumulado_margen_bruto_repuestos = acumulado_margen_bruto_repuestos + ((precio_venta_congelado - costo_compra_congelado) * cantidad_repuesto)
                elif linea_individual[0] == "PRUEBA" and linea_individual[1] == "FINAL":
                    acumulado_suma_errores_finales = acumulado_suma_errores_finales + float(linea_individual[2])
                    contador_pruebas_finales_totales = contador_pruebas_finales_totales + 1

        lista_tuplas_servicios = []
        for codigo_servicio in diccionario_conteo_veces_servicio:
            lista_tuplas_servicios.append((codigo_servicio, diccionario_conteo_veces_servicio[codigo_servicio]))
        
        numero_elementos = len(lista_tuplas_servicios)
        indice_externo = 0
        while indice_externo < numero_elementos - 1:
            indice_interno = 0
            while indice_interno < numero_elementos - indice_externo - 1:
                if lista_tuplas_servicios[indice_interno][1] < lista_tuplas_servicios[indice_interno+1][1]:
                    elemento_temporal = lista_tuplas_servicios[indice_interno]
                    lista_tuplas_servicios[indice_interno] = lista_tuplas_servicios[indice_interno+1]
                    lista_tuplas_servicios[indice_interno+1] = elemento_temporal
                indice_interno = indice_interno + 1
            indice_externo = indice_externo + 1

        promedio_error_calculado = 0.0
        if contador_pruebas_finales_totales > 0:
            promedio_error_calculado = acumulado_suma_errores_finales / contador_pruebas_finales_totales

        return {
            "facturacion_servicios": diccionario_total_facturado_por_servicio,
            "conteo_servicios": diccionario_conteo_veces_servicio,
            "margen_repuestos": acumulado_margen_bruto_repuestos,
            "top_servicios": lista_tuplas_servicios,
            "promedio_error_final": promedio_error_calculado,
            "tiene_pruebas": contador_pruebas_finales_totales > 0
        }
    except KeyError as error_clave:
        return {"facturacion_servicios": {}, "conteo_servicios": {}, "margen_repuestos": 0.0, "top_servicios": [], "promedio_error_final": 0.0, "tiene_pruebas": False}
    except ValueError as error_valor:
        return {"facturacion_servicios": {}, "conteo_servicios": {}, "margen_repuestos": 0.0, "top_servicios": [], "promedio_error_final": 0.0, "tiene_pruebas": False}
    except Exception as error_general:
        return {"facturacion_servicios": {}, "conteo_servicios": {}, "margen_repuestos": 0.0, "top_servicios": [], "promedio_error_final": 0.0, "tiene_pruebas": False}

# Ejecución inicial para garantizar que las carpetas existan de forma automática
asegurar_existencia_carpetas()

# Bucle principal de ejecución del menú interactivo con control de errores
bandera_programa_activo = True
opcion_menu_seleccionada = -1

while bandera_programa_activo:
    try:
        print("\n================= SISTEMA CENTRO TÉCNICO =================")
        print("1. Consultar información")
        print("2. Abrir orden nueva")
        print("3. Añadir servicio y repuestos a orden")
        print("4. Registrar prueba de error porcentual")
        print("5. Consultar y simular cierre de orden")
        print("6. Cerrar, facturar y archivar orden")
        print("7. Reportes técnicos y de inventario")
        print("0. Guardar y salir")
        
        entrada_texto_usuario = input("Seleccione una opción: ").strip()
        opcion_menu_seleccionada = int(entrada_texto_usuario)
        
        lista_equipos_cargada = cargar_datos_desde_archivo_csv("proyectofinal/equipos.csv")
        lista_servicios_cargada = cargar_datos_desde_archivo_csv("proyectofinal/servicios.csv")
        lista_repuestos_cargada = cargar_datos_desde_archivo_csv("proyectofinal/repuestos.csv")
        
        if opcion_menu_seleccionada == 1:
            print("\n--- CONSULTAR INFORMACIÓN ---")
            print("1. Ver Equipos")
            print("2. Ver Servicios")
            print("3. Ver Repuestos e Inventario")
            print("4. Ver Órdenes Abiertas")
            opcion_consulta = input("Seleccione una opción: ")
            
            if opcion_consulta == "1":
                print("\nEQUIPOS REGISTRADOS:")
                for eq in lista_equipos_cargada:
                    print("ID:", eq["equipo_id"], "| Cliente:", eq["cliente"], "| Tipo:", eq["tipo"], "| Modelo:", eq["modelo"], "| Estado:", eq["estado"])
            elif opcion_consulta == "2":
                print("\nCATÁLOGO DE SERVICIOS:")
                for s in lista_servicios_cargada:
                    print("Código:", s["codigo"], "| Desc:", s["descripcion"], "| Costo Fijo:", s["costo_fijo"], "| Costo Móvil:", s["costo_movil"])
            elif opcion_consulta == "3":
                print("\nINVENTARIO DE REPUESTOS:")
                for r in lista_repuestos_cargada:
                    print("Código:", r["codigo"], "| Desc:", r["descripcion"], "| Compra:", r["costo_compra"], "| Venta:", r["precio_venta"], "| Stock:", r["stock"])
            elif opcion_consulta == "4":
                print("\nÓRDENES ABIERTAS:")
                archivos_ots = listar_todos_los_archivos_de_ordenes("ordenes_abiertas")
                if len(archivos_ots) == 0:
                    print("No hay órdenes abiertas.")
                else:
                    for ar in archivos_ots:
                        datos_ot = leer_contenido_orden_txt("proyectofinal/ordenes_abiertas/" + ar)
                        cab = datos_ot["cabecera"]
                        if cab.get("estado") == "ABIERTA":
                            print("OT:", cab.get("ot"), "| Equipo:", cab.get("equipo_id"), "| Fecha:", cab.get("fecha"), "| Estado:", cab.get("estado"))
            else:
                print("Opción inválida.")
                
        elif opcion_menu_seleccionada == 2:
            print("\n--- ABRIR ORDEN NUEVA ---")
            id_eq = input("Ingrese el ID del equipo (ej. EQ02): ").strip().upper()
            cod_ot = input("Ingrese el código de la nueva OT (ej. OT003): ").strip().upper()
            fec = input("Ingrese la fecha (YYYY-MM-DD): ").strip()
            
            mensaje_resultado = logica_abrir_nueva_orden(id_eq, cod_ot, fec, lista_equipos_cargada)
            print(mensaje_resultado)
            
        elif opcion_menu_seleccionada == 3:
            print("\n--- AÑADIR SERVICIO O REPUESTO A ORDEN ---")
            cod_ot_obj = input("Ingrese el código de la OT abierta (ej. OT001): ").strip().upper()
            print("1. Añadir Servicio")
            print("2. Añadir Repuesto")
            sub_op = input("Seleccione qué desea añadir: ")
            
            if sub_op == "1":
                cod_serv = input("Ingrese código de servicio (ej. S01): ").strip().upper()
                msg = logica_anadir_servicio(cod_ot_obj, cod_serv, lista_equipos_cargada, lista_servicios_cargada)
                print(msg)
            elif sub_op == "2":
                cod_rep = input("Ingrese código de repuesto (ej. R01): ").strip().upper()
                cant_rep = int(input("Ingrese la cantidad: "))
                msg = logica_anadir_repuesto(cod_ot_obj, cod_rep, cant_rep, lista_repuestos_cargada)
                print(msg)
            else:
                print("Opción inválida.")
                
        elif opcion_menu_seleccionada == 4:
            print("\n--- REGISTRAR PRUEBA DE CALIBRACIÓN ---")
            cod_ot_obj = input("Ingrese el código de la OT abierta (ej. OT001): ").strip().upper()
            tipo_pr = input("Tipo de prueba (INICIAL / FINAL): ").strip().upper()
            val_err = float(input("Ingrese el porcentaje de error real (ej. 4.5): "))
            
            msg = logica_registrar_prueba(cod_ot_obj, tipo_pr, val_err)
            print(msg)
            
        elif opcion_menu_seleccionada == 5:
            print("\n--- SIMULAR CIERRE DE ORDEN ---")
            cod_ot_obj = input("Ingrese el código de la OT abierta: ").strip().upper()
            sim = logica_simular_cierre(cod_ot_obj)
            if "mensaje" in sim:
                print(sim["mensaje"])
            else:
                print("\n--- RESULTADO DE SIMULACIÓN ---")
                print("¿Tiene al menos un servicio?:", "SÍ" if sim["tiene_servicio"] else "NO")
                print("¿Tiene prueba INICIAL?:", "SÍ" if sim["tiene_inicial"] else "NO")
                print("¿Tiene última prueba FINAL?:", str(sim["ultima_final"]) + "%" if sim["ultima_final"] is not None else "NO")
                print("ESTADO:", sim["estado"])
                
        elif opcion_menu_seleccionada == 6:
            print("\n--- CERRAR, FACTURAR Y ARCHIVAR ORDEN ---")
            cod_ot_obj = input("Ingrese el código de la OT a cerrar: ").strip().upper()
            res_cierre = logica_cerrar_y_facturar_orden(cod_ot_obj, lista_equipos_cargada)
            if not res_cierre["exito"]:
                print(res_cierre["mensaje"])
            else:
                print("\n================ FACTURA GENERADA ================")
                print("Orden:", res_cierre["ot"], "| Equipo:", res_cierre["equipo"])
                print("Subtotal Mano de Obra:", res_cierre["mano_obra"])
                print("Subtotal Repuestos:", res_cierre["repuestos"])
                print("Subtotal General:", res_cierre["subtotal"])
                print("IVA Académico (19%):", res_cierre["iva"])
                print("TOTAL A PAGAR:", res_cierre["total"])
                print("===================================================")
                print("¡Orden cerrada, facturada y archivada exitosamente!")
                
        elif opcion_menu_seleccionada == 7:
            print("\n--- REPORTES TÉCNICOS Y DE INVENTARIO ---")
            rep = calcular_reportes_tecnicos()
            
            print("\n1. Facturación total por código de servicio:")
            for cod, total_serv in rep["facturacion_servicios"].items():
                print(f"  - Servicio {cod}: Total acumulado = {total_serv} | Realizados: {rep['conteo_servicios'][cod]}")
                
            print("\n2. Margen bruto de repuestos (órdenes cerradas):", rep["margen_repuestos"])
            
            print("\n3. Top 3 servicios más frecuentes:")
            contador_top = 0
            for tupla_item in rep["top_servicios"]:
                if contador_top < 3:
                    print(f"  - Código: {tupla_item[0]} | Veces realizado: {tupla_item[1]}")
                    contador_top = contador_top + 1
                    
            print("\n4. Promedio del error FINAL en órdenes cerradas:")
            if rep["tiene_pruebas"]:
                print(f"  - Promedio error final: {rep['promedio_error_final']}%")
            else:
                print("  - No hay pruebas finales registradas en órdenes cerradas.")
                
            print("\n5. Inventario crítico (Stock < 5):")
            for repuesto_item in lista_repuestos_cargada:
                if int(repuesto_item["stock"]) < 5:
                    print(f"  - Repuesto: {repuesto_item['codigo']} | Descripción: {repuesto_item['descripcion']} | Stock actual: {repuesto_item['stock']}")
                    
        elif opcion_menu_seleccionada == 0:
            print("Guardando y cerrando sistema... ¡Hasta luego!")
            bandera_programa_activo = False
        else:
            print("Opción inválida. Por favor, seleccione un número del 0 al 7.")
            
    except ValueError as error_valor:
        print(f"Error de valor ingresado: {error_valor}")
    except KeyError as error_clave:
        print(f"Error de referencia de clave: {error_clave}")
    except FileNotFoundError as error_archivo:
        print(f"Error de archivo: {error_archivo}")
    except Exception as error_general:
        print(f"Se ha producido un error inesperado en la operación: {error_general}")
    else:
        if opcion_menu_seleccionada != 0:
            print(">>> Operación ejecutada exitosamente.")
    finally:
        print("--- Fin del ciclo de ejecución actual ---\n")